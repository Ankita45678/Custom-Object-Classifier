import java.util.*;
public class roundrobin 
{
	Scanner sc=new Scanner(System.in);
	int n;
	int wt[];
	int tat[];
	int ct[],rembt[];
	
	void execute()
	{
		System.out.println("\nEnter number of processes : ");
		n=sc.nextInt();
		process pr[]=new process[n];
		wt=new int[n];
		tat=new int[n];
		ct=new int[n];
		rembt=new int[n];
		System.out.println("\nEnter Burst Time : ");
		int bt,at;
		for(int i=0;i<n;i++)
		{
			System.out.println("\nBurst Time : ");
			bt=sc.nextInt();
			at=0;
			pr[i]=new process(i+1,bt,at);
		}
		int ts;
		System.out.println("\nEnter quantum time : ");
		ts=sc.nextInt();
		
		for(int i=0;i<n;i++)
		{
			rembt[i]=pr[i].bt;
		}
		
		boolean done;
		int time=0;
		while(true)
		{
			done=true;
			for(int i=0;i<n;i++)
			{
				if(rembt[i]>0)
				{
					if(rembt[i]>ts)//remaining time more than window size
					{
						done=false;//process not completed yet
						time+=ts;
						rembt[i]-=ts;
					}
					else
					{
						time+=rembt[i];
						ct[i]=time;
						wt[i]=time-pr[i].bt;
						tat[i]=wt[i]+pr[i].bt;
						rembt[i]=0;
					}
				}
			}
			if(done==true)
			{
				break;
			}
		}
		display(pr);
		int sum=0;
		double avgWT=0,avgTAT=0;
		for(int i=0;i<n;i++)
		{
			avgWT=avgWT+wt[i];
			avgTAT=avgTAT+tat[i];
		}
		avgTAT=(double)avgTAT/n;
		avgWT=(double)avgWT/n;
		System.out.println("Average Waiting Time"+avgWT);
		System.out.println("Average TAT="+avgTAT);

	}
	void display(process[] proc)
	{
		System.out.println("\nProcess   BT\tAT\tWT\tTAT\tCT\t");
		for(int i=0;i<n;i++)
		{
			System.out.println(proc[i].processid+"\t"+proc[i].bt+"\t"+proc[i].at+"\t"+wt[i]+"\t"+tat[i]+"\t"+ct[i]);
		}
	}
	
	public static void main(String[] args)
	{
		roundrobin r=new roundrobin();
		r.execute();
	}
}