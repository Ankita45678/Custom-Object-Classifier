import java.util.*;
import java.io.*;

public class bankers
{
	Scanner obj = new Scanner(System.in);
	int i = 0;
	int flag = 0;
	int count = 0;
	
	int[][] need;
	int[][] allocation;
	int[][] max;
	int[] available;
	int[] work;
	int[] finish;
	
	public bankers(int n, int m)
	{
		need = new int[n][m];
		allocation = new int[n][m];
		max = new int[n][m];
		available = new int[m];
		work = new int[m];
		finish = new int[n];
	}
	
	public void input(int n , int m)
	{
		System.out.println("Allocation matrix: ");
		for(int j=0; j<n; j++)
		{
			for(int k=0; k<m; k++)
			{
				System.out.println("Enter the allocation: ");
				allocation[j][k] = obj.nextInt();
			}
		}
		System.out.println("Max matrix: ");
		for(int j=0; j<n; j++)
		{
			for(int k=0; k<m; k++)
			{
				System.out.println("Enter the max: ");
				max[j][k] = obj.nextInt();
			}
		}
		
		for(int j=0; j<n; j++)
		{
			for(int k=0; k<m; k++)
			{
				need[j][k] = max[j][k] - allocation[j][k];
			}
			finish[j] = 0;
		}
		System.out.println("Available matrix: ");
		for(int k=0; k<m; k++)
		{
			System.out.println("Enter the available: ");
			available[k] = obj.nextInt();
			work[k] = available[k];
		}
	}
	public void process(int n, int m)
	{
		for(i=0; ; i++)
		{
			i = i%n;
			
			if(finish[i]==0)
			{
				for(int j=0; j<m; j++)
				{
					if(need[i][j] <= work[j])
					{
						flag = 1;
					}
					else
					{
						flag = 0;
						break;
					}
				}
				if(flag==1)
				{
					for(int j=0; j<m; j++)
					{
						work[j] = work[j] + allocation[i][j];
						finish[i] = 1;
					}
					count++;
					System.out.println("P" + i);
				}
			}
			if(count==n)
			{
				break;
			}
		}
	}
	public static void main(String args[])
	{
		Scanner obj = new Scanner(System.in);
		
		System.out.println("Enter the number of resource types: ");
		int m = obj.nextInt();
		System.out.println("Enter the number of processes: ");
		int n = obj.nextInt();
		
		bankers b = new bankers(n, m);
		
		b.input(n, m);
		System.out.println("Safe sequence is: ");
		b.process(n, m);
	}
}
