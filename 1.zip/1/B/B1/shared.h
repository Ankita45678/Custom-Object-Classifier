#include<stdio.h>
extern unsigned int add(unsigned int a, unsigned int b);
extern unsigned int sub(unsigned int a, unsigned int b);
extern unsigned int mult(unsigned int a, unsigned int b);
