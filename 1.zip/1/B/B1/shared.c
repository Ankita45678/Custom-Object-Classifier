#include "shared.h"
unsigned int add(unsigned int a, unsigned int b)
{
    printf("\n Inside add()\n");
    return (a+b);
}

unsigned int sub(unsigned int a, unsigned int b)
{
    printf("\n Inside sub()\n");
    return (a-b);
}

unsigned int mult(unsigned int a, unsigned int b)
{
    printf("\n Inside mult()\n");
    return (a*b);
}
