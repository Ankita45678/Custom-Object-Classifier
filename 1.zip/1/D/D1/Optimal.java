import java.util.*;

public class Optimal {
	
	public static void main(String args[])
	{
		int pageFault=0;
		int nFrames,nPages;
		Scanner s=new Scanner(System.in);
		int i,j,k,l;
		
		System.out.println("Enter the number of pages: ");
		nPages=s.nextInt();
		int pages[]=new int[nPages];
		
		System.out.println("Enter the page reference string: ");
		for(i=0;i<nPages;i++)
		{
			pages[i]=s.nextInt();
		}
		
		System.out.println("\n Enter the numbe of frmaes: ");
		nFrames=s.nextInt();
		
		int frames[]=new int[nFrames];
		
		for(i=0;i<nFrames;i++)
		{
			frames[i]=-1;
		}
		
		for(i=0;i<nPages;i++)
		{
			int isFrameEmpty=0;
			for(j=0;j<nFrames;j++)
			{
				if(frames[j]==-1)
				{
					isFrameEmpty=1;
					break;
				}
			}
			
			if(isFrameEmpty==1)
			{
				frames[j]=pages[i];
				pageFault++;
			}
			else
			{
				int isPageAlreadyPresent=0;
				
				for(j=0;j<nFrames;j++)
				{
					if(pages[i]==frames[j])
					{
						isPageAlreadyPresent=1;
						break;
					}
				}
				
				if(isPageAlreadyPresent==0)
				{
					pageFault++;
					int temp[]=new int[nFrames];
					
					for(k=0;k<nFrames;k++)
					{
						temp[k]=-1;
						for(l=i+1;l<nPages-1;l++)
						{
							if(frames[k]==pages[l])
							{
								temp[k]=l;
								break;
							}
						}
					}
					
					int pos=-1;
					int flag=0;
					for(l=0;l<nFrames;l++)
					{
						if(temp[l]==-1)
						{
							pos=l;
							flag=1;
							break;
						}
					}
					
					if(flag==1)
					{
						frames[pos]=pages[i];
					}
					else
					{
						int max=temp[0];
						pos=0;
						for(k=1;k<nFrames;k++)
						{
							if(max<temp[k])
							{
								pos=k;
								max=temp[k];
							}
						}
						frames[pos]=pages[i];
					}
				}
			}
			for(j=0;j<nFrames;j++)
			{
				System.out.print(frames[j]+" ");
			}
			System.out.println("");
		}
		
		System.out.println("Page Faults: "+pageFault);
		
	}

}
