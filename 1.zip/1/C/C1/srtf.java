import java.util.*;
public class srtf 
{
	int n;
	Scanner sc=new Scanner(System.in);
	int wt[],tat[],ct[];
	void findwaitingtime()
	{
		System.out.println("\nEnter number of processes : ");
		n=sc.nextInt();
		process pr[]=new process[n];
		wt=new int[n];
		tat=new int[n];
		ct=new int[n];
		System.out.println("\nEnter Burst Time and Arrival Time : ");
		int bt,at;
		for(int i=0;i<n;i++)
		{
			System.out.println("\nBurst Time : ");
			bt=sc.nextInt();
			System.out.println("\nArrival Time : ");
			at=sc.nextInt();
			pr[i]=new process(i+1,bt,at);
		}
		
		int rt[]=new int[n];
		for(int i=0;i<n;i++)
		{
			rt[i]=pr[i].bt;
		}
		
		int complete=0,t=0;
		int min=Integer.MAX_VALUE;
		int shortest=0, finishtime;
		boolean flag=false;
		
		while(complete!=n)
		{
			for(int i=0;i<n;i++)
			{
				if((pr[i].at<=t) && (rt[i]<min) && (rt[i]>0))
				{
					min=rt[i];
					shortest=i;
					flag=true;
				}
			}
			if(flag==false)
			{
				t++;
				continue;
			}
			
			rt[shortest]--;
			min=rt[shortest];
			if(min==0)
				min=Integer.MAX_VALUE;
			
			if(rt[shortest]==0)
			{
				complete++;
				flag=false;
				finishtime=t+1;
				ct[shortest]=finishtime;
				wt[shortest]=finishtime-pr[shortest].bt-pr[shortest].at;
				if(wt[shortest]<0)
					wt[shortest]=0;
			}
			
			t++;
		}
		turnaround(pr);
	}
	void turnaround(process[] proc)
	{
		for(int i=0;i<n;i++)
		{
			tat[i]=wt[i]+proc[i].bt;
		}
		int sum=0;
		double avgWT=0,avgTAT=0;
		for(int i=0;i<n;i++)
		{
			sum=ct[i]=sum+proc[i].bt;
			tat[i]=ct[i]-proc[i].at;
			wt[i]=tat[i]-proc[i].bt;

			avgWT=avgWT+wt[i];
			avgTAT=avgTAT+tat[i];

		}
		display(proc);
		avgTAT=(double)avgTAT/n;
		avgWT=(double)avgWT/n;
		System.out.println("Average Waiting Time"+avgWT);
		System.out.println("Average TAT="+avgTAT);

	}
	void display(process[] proc)
	{
		System.out.println("\nProcess   BT\tAT\tWT\tTAT\tCT");
		for(int i=0;i<n;i++)
		{
			System.out.println(proc[i].processid+"\t"+proc[i].bt+"\t"+proc[i].at+"\t"+wt[i]+"\t"+tat[i]+"\t"+ct[i]);
		}
	}
	public static void main(String[] args)
	{
		srtf s1=new srtf();
		s1.findwaitingtime();
	}
}